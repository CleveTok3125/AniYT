from typing import Dict


class Typing:
    Video = Dict[str, str]
