import functools
from typing import cast

import ujson as json

from .common import BookmarkData, Video
from .exceptions import CategoryNotExist, InvalidBookmarkFile
from .os_manager import OSManager


class BookmarkingHandler:
    def __init__(self):
        self.filename = "./data/bookmark.json"
        self.encoding = "utf-8"
        self.required_categories = ["bookmark", "completed"]

    def _save_full_data(self, data: BookmarkData) -> None:
        with open(self.filename, "w", encoding=self.encoding) as f:
            json.dump(data, f, indent=4, ensure_ascii=False)

    def _init_default_data(self) -> BookmarkData:
        # Return default valid structure.
        default_data: BookmarkData = cast(BookmarkData, {category: {} for category in self.required_categories})
        self._save_full_data(default_data)
        return default_data

    @staticmethod
    def validate_structure(func):
        @functools.wraps(func)  # type: ignore
        def wrapper(self, *args, **kwargs):
            data = func(self, *args, **kwargs)
            required_categories = getattr(self, "required_categories", [])

            if not isinstance(data, dict):
                raise InvalidBookmarkFile("Data structure must be a dictionary", self.filename)

            for category in required_categories:
                if category not in data:
                    raise InvalidBookmarkFile(f"Missing required category '{category}'", self.filename)

                if not isinstance(data[category], dict):
                    raise InvalidBookmarkFile(f"Category '{category}' must be a dictionary", self.filename)

            return data

        return wrapper

    @validate_structure
    def load_full_data(self) -> BookmarkData:
        if not OSManager.exists(self.filename):
            return self._init_default_data()
        try:
            with open(self.filename, encoding=self.encoding) as f:
                content = f.read()
                return cast(BookmarkData, json.loads(content)) if content else cast(BookmarkData, {})
        except (OSError, json.JSONDecodeError):
            return self._init_default_data()

    def get_category(self, category: str) -> dict[str, str]:
        full_data: BookmarkData = self.load_full_data()
        return full_data.get(category, {})

    def update_item(self, data: Video | list, category: str, create_new: bool = False) -> None:
        full_data: BookmarkData = self.load_full_data()

        if category not in full_data:
            if create_new:
                full_data[category] = {}
            else:
                raise CategoryNotExist(
                    f"Category '{category}' does not exist, need to create a new one.",
                    delay=-1,
                )

        bookmarks: dict[str, str] = full_data[category]

        if isinstance(data, dict):
            key, value = data.get("video_title"), data.get("video_url")
        else:
            key, value = data[0], data[1]

        if key is None or value is None:
            raise ValueError("Data must contain title and url")

        bookmarks[key] = value
        self._save_full_data(full_data)

    def is_item_exist(self, url: str, category: str) -> bool:
        items: dict[str, str] = self.get_category(category)
        return url in items.values()

    def remove_item(self, url: str, category: str) -> None:
        full_data: BookmarkData = self.load_full_data()

        if category not in full_data:
            return

        items: dict[str, str] = full_data[category]

        key_to_delete = None
        for key, value in items.items():
            if value == url:
                key_to_delete = key
                break

        if key_to_delete:
            del items[key_to_delete]
            self._save_full_data(full_data)

    def delete_file(self):
        OSManager.delete_file(self.filename)
