from .args_interface import ArgsHandler


def main():
    ArgsHandler().listener()


if __name__ == "__main__":
    main()
